from django.urls import path
from . import views

app_name = 'dashboard'

urlpatterns = [
    path('', views.dashboard_home, name='dashboard_home'),
    path('saved-reports/', views.saved_report_list, name='saved_report_list'),
    path('excess-fund-report/', views.excess_fund_report, name='excess_fund_report'),
    path('analytics/', views.superset_analytics, name='superset_analytics'),
    path('approvals/', views.approvals_center, name='approvals_center'),
]