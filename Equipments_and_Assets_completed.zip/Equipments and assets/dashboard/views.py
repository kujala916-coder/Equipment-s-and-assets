from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Sum
from .models import SavedReport
from .forms import SavedReportForm
from procurement.models import Procurement, ProcurementPlan, Requisition
from vendors.models import Vendor, VendorIssue
from contracts.models import Contract
from notifications.models import Notification


def dashboard_home(request):
    context = {
        'total_vendors': Vendor.objects.count(),
        'total_procurements': Procurement.objects.count(),
        'total_contracts': Contract.objects.count(),
        'active_contracts': Contract.objects.filter(status='active').count(),
        'open_vendor_issues': VendorIssue.objects.filter(status='open').count(),
        'pending_oic_approvals': Contract.objects.filter(
            oic_approval_required=True, oic_approved=False
        ).count(),
    }

    if request.user.is_authenticated:
        context['recent_notifications'] = Notification.objects.filter(
            recipient=request.user
        )[:5]
        # Reports, merged directly into the main dashboard instead of living
        # on their own disconnected page.
        context['saved_reports'] = SavedReport.objects.filter(
            created_by=request.user
        ).order_by('-created_at')[:10]

    context['excess_fund_summary'] = _excess_fund_summary()

    return render(request, 'dashboard/dashboard_home.html', context)


def _excess_fund_summary():
    """For each procurement plan: budget vs. what's actually been committed
    to procurements raised against it, so unused ('excess') funds are visible."""
    summary = []
    for plan in ProcurementPlan.objects.all():
        committed = Procurement.objects.filter(
            requisition__requirement__plan=plan
        ).aggregate(total=Sum('total_value'))['total'] or 0
        budget = plan.total_budget or 0
        summary.append({
            'plan': plan,
            'budget': budget,
            'committed': committed,
            'excess': budget - committed,
        })
    return summary


@login_required
def saved_report_list(request):
    if request.method == 'POST':
        form = SavedReportForm(request.POST)
        if form.is_valid():
            report = form.save(commit=False)
            report.created_by = request.user
            report.save()
            messages.success(request, "Report saved.")
            return redirect('dashboard:saved_report_list')
    else:
        form = SavedReportForm()

    return render(request, 'dashboard/saved_report_list.html', {
        'reports': SavedReport.objects.filter(created_by=request.user).order_by('-created_at'),
        'form': form,
    })


@login_required
def excess_fund_report(request):
    return render(request, 'dashboard/excess_fund_report.html', {
        'summary': _excess_fund_summary(),
    })


@login_required
def superset_analytics(request):
    """Embeds the Superset dashboard configured in settings using a
    short-lived guest token, so no Superset password ever reaches the browser."""
    from django.conf import settings
    import requests

    context = {
        'superset_url': getattr(settings, 'SUPERSET_URL', ''),
        'dashboard_id': getattr(settings, 'SUPERSET_DASHBOARD_ID', ''),
        'guest_token': None,
        'error': None,
    }

    try:
        base = settings.SUPERSET_URL.rstrip('/')
        login_resp = requests.post(
            f"{base}/api/v1/security/login",
            json={
                "username": settings.SUPERSET_USERNAME,
                "password": settings.SUPERSET_PASSWORD,
                "provider": "db",
                "refresh": True,
            },
            timeout=5,
        )
        login_resp.raise_for_status()
        access_token = login_resp.json()["access_token"]

        guest_resp = requests.post(
            f"{base}/api/v1/security/guest_token/",
            json={
                "user": {"username": request.user.username, "first_name": request.user.first_name or request.user.username, "last_name": request.user.last_name or ""},
                "resources": [{"type": "dashboard", "id": settings.SUPERSET_DASHBOARD_ID}],
                "rls": [],
            },
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=5,
        )
        guest_resp.raise_for_status()
        context['guest_token'] = guest_resp.json()["token"]
    except Exception as e:
        # Superset may not be running/reachable — show the page with a clear
        # message instead of a hard 500.
        context['error'] = f"Could not connect to Superset: {e}"

    return render(request, 'dashboard/superset_analytics.html', context)


@login_required
def approvals_center(request):
    """One centralized place for every pending approval across the system
    (Requisitions — Procurement approval, Requisitions — OIC approval,
    Contracts — OIC approval) instead of three separate scattered pages."""
    requisitions_pending = Requisition.objects.filter(
        approved_by__isnull=True
    ).select_related('requirement', 'requirement__plan').order_by('id')

    requisitions_oic_pending = Requisition.objects.filter(
        oic_approval_required=True, oic_approved=False
    ).select_related('requirement', 'requirement__plan').order_by('id')

    contracts_oic_pending = Contract.objects.filter(
        oic_approval_required=True, oic_approved=False
    ).select_related('vendor').order_by('created_at')

    context = {
        'requisitions_pending': requisitions_pending,
        'requisitions_oic_pending': requisitions_oic_pending,
        'contracts_oic_pending': contracts_oic_pending,
        'can_approve_requisition': request.user.has_perm('procurement.change_requisition'),
        'is_oic': request.user.is_superuser,
    }
    return render(request, 'dashboard/approvals_center.html', context)