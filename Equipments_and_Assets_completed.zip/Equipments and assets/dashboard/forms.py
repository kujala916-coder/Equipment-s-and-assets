from django import forms
from .models import SavedReport


class SavedReportForm(forms.ModelForm):
    class Meta:
        model = SavedReport
        fields = ["name", "report_type", "filters"]
        widgets = {
            "filters": forms.Textarea(attrs={"rows": 3, "placeholder": '{"key": "value"} (optional JSON filters)'}),
        }
