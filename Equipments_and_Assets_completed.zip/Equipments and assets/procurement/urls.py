from django.urls import path
from . import views

app_name = 'procurement'

urlpatterns = [
    path('plans/', views.plan_list, name='plan_list'),
    path('requirements/', views.requirement_list, name='requirement_list'),
    path('requisitions/', views.requisition_list, name='requisition_list'),
    path('requisitions/approvals/', views.requisition_approvals, name='requisition_approvals'),
    path('requisitions/status/', views.requisition_status_list, name='requisition_status_list'),
    path('requisitions/<int:pk>/', views.requisition_detail, name='requisition_detail'),
    path('requisitions/<int:pk>/approve/', views.requisition_approve, name='requisition_approve'),
    path('requisitions/oic-approvals/', views.requisition_oic_approvals, name='requisition_oic_approvals'),
    path('requisitions/<int:pk>/oic-approve/', views.requisition_oic_approve, name='requisition_oic_approve'),
    path('requisitions/<int:pk>/send-email/', views.requisition_send_email, name='requisition_send_email'),
    path('', views.procurement_list, name='procurement_list'),
    path('items/', views.procurement_item_list, name='procurement_item_list'),
    path('specifications/', views.specification_list, name='specification_list'),
    path('evaluations/', views.evaluation_list, name='evaluation_list'),
    path('evaluation-items/', views.evaluation_item_list, name='evaluation_item_list'),
]