from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied
from django.core.mail import send_mail
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from .forms import (
    ProcurementPlanForm, ProcurementRequirementForm, RequisitionForm,
    ProcurementForm, ProcurementItemForm, TechnicalSpecificationForm,
    TechnicalEvaluationForm, EvaluationItemForm, SendApprovalEmailForm
)
from .models import Requisition


def _block_post_without_add(request, codename):
    """View-only roles (e.g. Manager) can GET these pages but must never be
    able to submit the form, even though they have view_* permission."""
    if request.method == 'POST' and not request.user.has_perm(codename):
        raise PermissionDenied("You have view-only access and cannot add records.")


@login_required
@permission_required("procurement.view_procurementplan", raise_exception=True)
def plan_list(request):
    _block_post_without_add(request, "procurement.add_procurementplan")
    if request.method == 'POST':
        form = ProcurementPlanForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Procurement plan saved.")
            return redirect('procurement:plan_list')
    else:
        form = ProcurementPlanForm()

    return render(request, 'procurement/generic_form.html', {
        'form': form, 'form_title': 'Procurement Plan', 'objects': form._meta.model.objects.all()[:200],
        'can_add': request.user.has_perm('procurement.add_procurementplan'),
    })


@login_required
@permission_required("procurement.view_procurementrequirement", raise_exception=True)
def requirement_list(request):
    _block_post_without_add(request, "procurement.add_procurementrequirement")
    if request.method == 'POST':
        form = ProcurementRequirementForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Procurement requirement saved.")
            return redirect('procurement:requirement_list')
    else:
        form = ProcurementRequirementForm()

    return render(request, 'procurement/generic_form.html', {
        'form': form, 'form_title': 'Procurement Requirement', 'objects': form._meta.model.objects.all()[:200],
        'can_add': request.user.has_perm('procurement.add_procurementrequirement'),
    })


@login_required
@permission_required("procurement.view_requisition", raise_exception=True)
def requisition_list(request):
    _block_post_without_add(request, "procurement.add_requisition")
    if request.method == 'POST':
        form = RequisitionForm(request.POST)
        if form.is_valid():
            requisition = form.save(commit=False)
            requisition.oic_approval_required = requisition.needs_oic_approval()
            if requisition.oic_approval_required:
                # A fresh save always starts unapproved; OIC signs off separately.
                requisition.oic_approved = False
                requisition.oic_approved_by = None
                requisition.oic_approved_at = None
            requisition.save()
            if requisition.oic_approval_required:
                messages.warning(
                    request,
                    f"Requisition raised, but its estimated value is above Rs. "
                    f"{Requisition.OIC_APPROVAL_THRESHOLD:,} so it needs OIC approval "
                    "in addition to the normal Procurement approval."
                )
            else:
                messages.success(request, "Requisition raised. It now needs approval before procurement can start.")
            return redirect('procurement:requisition_list')
    else:
        form = RequisitionForm()

    requisitions = Requisition.objects.select_related(
        'requirement', 'requirement__plan', 'approved_by', 'oic_approved_by'
    ).order_by('-id')

    return render(request, 'procurement/requisition_list.html', {
        'form': form, 'form_title': 'Requisition', 'objects': form._meta.model.objects.all()[:200],
        'can_add': request.user.has_perm('procurement.add_requisition'),
        'requisitions': requisitions,
        'oic_threshold': Requisition.OIC_APPROVAL_THRESHOLD,
    })


@login_required
@permission_required("procurement.view_requisition", raise_exception=True)
def requisition_approvals(request):
    """List of requisitions still waiting on approval."""
    pending = Requisition.objects.filter(approved_by__isnull=True).select_related(
        'requirement', 'requirement__plan'
    ).order_by('id')
    return render(request, 'procurement/requisition_approval_list.html', {'pending': pending})


@login_required
@permission_required("procurement.view_requisition", raise_exception=True)
def requisition_status_list(request):
    """Every requisition (approved or not), so Manager/Procurement can check
    status at any time — not just while it's still pending."""
    requisitions = Requisition.objects.select_related(
        'requirement', 'requirement__plan', 'approved_by', 'oic_approved_by'
    ).order_by('-id')
    return render(request, 'procurement/requisition_status_list.html', {'requisitions': requisitions})


@login_required
@permission_required("procurement.view_requisition", raise_exception=True)
def requisition_detail(request, pk):
    """A printable 'document' view of one requisition's approval status —
    the thing a Manager can pull up any time to confirm approved/remarks."""
    requisition = get_object_or_404(
        Requisition.objects.select_related('requirement', 'requirement__plan', 'approved_by', 'oic_approved_by'),
        pk=pk
    )
    return render(request, 'procurement/requisition_detail.html', {'requisition': requisition})


@login_required
def requisition_approve(request, pk):
    """Only someone who can actually change requisitions (Procurement role or
    Admin — never a view-only Manager) can approve one, with remarks.

    If OIC approval is required for this requisition (estimated value above
    the threshold), it must be approved by the OIC FIRST — Procurement
    approval is blocked until then.
    """
    if not request.user.has_perm("procurement.change_requisition"):
        raise PermissionDenied("You have view-only access and cannot approve requisitions.")
    requisition = get_object_or_404(Requisition, pk=pk)
    oic_blocking = requisition.oic_approval_required and not requisition.oic_approved

    if request.method == 'POST':
        if oic_blocking:
            messages.error(
                request,
                f"Requisition #{requisition.pk} needs OIC approval first — its estimated value is "
                f"above Rs. {Requisition.OIC_APPROVAL_THRESHOLD:,}. It can't be approved until the "
                "OIC signs off."
            )
            return redirect('procurement:requisition_detail', pk=requisition.pk)
        requisition.approved_by = request.user
        requisition.approval_date = timezone.now()
        requisition.remarks = request.POST.get('remarks', '').strip()
        requisition.save()
        messages.success(request, f"Requisition #{requisition.pk} approved.")
        return redirect('procurement:requisition_detail', pk=requisition.pk)

    return render(request, 'procurement/requisition_approve_form.html', {
        'requisition': requisition,
        'oic_blocking': oic_blocking,
    })


@login_required
@permission_required("procurement.view_requisition", raise_exception=True)
def requisition_oic_approvals(request):
    """List of high-value requisitions still waiting on OIC sign-off."""
    pending = Requisition.objects.filter(
        oic_approval_required=True, oic_approved=False
    ).select_related('requirement', 'requirement__plan').order_by('id')
    return render(request, 'procurement/requisition_oic_approval_list.html', {'pending': pending})


@login_required
def requisition_oic_approve(request, pk):
    """Only the OIC (an Admin/superuser) can approve a high-value requisition —
    same restriction as Contract's OIC approval."""
    if not request.user.is_superuser:
        raise PermissionDenied("Only an OIC/Admin can approve this requisition.")
    requisition = get_object_or_404(Requisition, pk=pk)
    if request.method == 'POST':
        requisition.oic_approved = True
        requisition.oic_remarks = request.POST.get('remarks', '').strip()
        requisition.oic_approved_by = request.user
        requisition.oic_approved_at = timezone.now()
        requisition.save()
        messages.success(request, f"Requisition #{requisition.pk} approved by OIC.")
        return redirect('procurement:requisition_oic_approvals')
    return render(request, 'procurement/requisition_oic_approve_form.html', {'requisition': requisition})


@login_required
@permission_required("procurement.view_requisition", raise_exception=True)
def requisition_send_email(request, pk):
    """Email a requisition's item/quantity/price and approval status to an
    official nlc.com.pk address — used from the detail and approve pages."""
    requisition = get_object_or_404(
        Requisition.objects.select_related('requirement', 'requirement__plan', 'approved_by', 'oic_approved_by'),
        pk=pk
    )
    if request.method == 'POST':
        form = SendApprovalEmailForm(request.POST)
        if form.is_valid():
            to_email = form.cleaned_data['email']
            requirement = requisition.requirement
            total = requirement.estimated_total_price
            subject = f"Requisition #{requisition.pk} — {requirement.item_name}"
            body_lines = [
                f"Requisition #{requisition.pk}",
                f"Item: {requirement.item_name}",
                f"Quantity: {requirement.quantity}",
                f"Estimated Total: Rs. {total:,.2f}" if total is not None else "Estimated Total: —",
                f"Plan: {requirement.plan}",
                "",
                f"Procurement Approval: {'Approved by ' + str(requisition.approved_by) if requisition.approved_by else 'Pending'}",
            ]
            if requisition.oic_approval_required:
                body_lines.append(
                    "OIC Approval: " + (
                        f"Approved by {requisition.oic_approved_by}" if requisition.oic_approved else "Pending"
                    )
                )
            if requisition.remarks:
                body_lines.append(f"Remarks: {requisition.remarks}")
            body_lines += ["", f"Sent by {request.user.get_username()} via IT Equipment & Stores Management."]

            send_mail(subject, "\n".join(body_lines), None, [to_email], fail_silently=False)
            messages.success(request, f"Requisition #{requisition.pk} details emailed to {to_email}.")
        else:
            messages.error(request, "Please enter a valid official email address (e.g. name@nlc.com.pk).")

    referer = request.META.get('HTTP_REFERER')
    if referer and url_has_allowed_host_and_scheme(referer, allowed_hosts={request.get_host()}):
        return redirect(referer)
    return redirect('procurement:requisition_detail', pk=requisition.pk)


@login_required
@permission_required("procurement.view_procurement", raise_exception=True)
def procurement_list(request):
    _block_post_without_add(request, "procurement.add_procurement")
    if request.method == 'POST':
        form = ProcurementForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Procurement record saved.")
            return redirect('procurement:procurement_list')
    else:
        form = ProcurementForm()

    return render(request, 'procurement/generic_form.html', {
        'form': form, 'form_title': 'Procurement', 'objects': form._meta.model.objects.all()[:200],
        'can_add': request.user.has_perm('procurement.add_procurement'),
    })


@login_required
@permission_required("procurement.view_procurementitem", raise_exception=True)
def procurement_item_list(request):
    _block_post_without_add(request, "procurement.add_procurementitem")
    if request.method == 'POST':
        form = ProcurementItemForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Procurement item saved.")
            return redirect('procurement:procurement_item_list')
    else:
        form = ProcurementItemForm()

    return render(request, 'procurement/generic_form.html', {
        'form': form, 'form_title': 'Procurement Item', 'objects': form._meta.model.objects.all()[:200],
        'can_add': request.user.has_perm('procurement.add_procurementitem'),
    })


@login_required
@permission_required("procurement.view_technicalspecification", raise_exception=True)
def specification_list(request):
    _block_post_without_add(request, "procurement.add_technicalspecification")
    if request.method == 'POST':
        form = TechnicalSpecificationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Technical specification saved.")
            return redirect('procurement:specification_list')
    else:
        form = TechnicalSpecificationForm()

    return render(request, 'procurement/generic_form.html', {
        'form': form, 'form_title': 'Technical Specification', 'objects': form._meta.model.objects.all()[:200],
        'can_add': request.user.has_perm('procurement.add_technicalspecification'),
    })


@login_required
@permission_required("procurement.view_technicalevaluation", raise_exception=True)
def evaluation_list(request):
    _block_post_without_add(request, "procurement.add_technicalevaluation")
    if request.method == 'POST':
        form = TechnicalEvaluationForm(request.POST)
        if form.is_valid():
            evaluation = form.save(commit=False)
            if request.user.is_authenticated:
                evaluation.evaluated_by = request.user
            evaluation.save()
            messages.success(request, "Technical evaluation saved.")
            return redirect('procurement:evaluation_list')
    else:
        form = TechnicalEvaluationForm()

    return render(request, 'procurement/generic_form.html', {
        'form': form, 'form_title': 'Technical Evaluation', 'objects': form._meta.model.objects.all()[:200],
        'can_add': request.user.has_perm('procurement.add_technicalevaluation'),
    })


@login_required
@permission_required("procurement.view_evaluationitem", raise_exception=True)
def evaluation_item_list(request):
    _block_post_without_add(request, "procurement.add_evaluationitem")
    if request.method == 'POST':
        form = EvaluationItemForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Evaluation item saved.")
            return redirect('procurement:evaluation_item_list')
    else:
        form = EvaluationItemForm()

    return render(request, 'procurement/generic_form.html', {
        'form': form, 'form_title': 'Evaluation Item', 'objects': form._meta.model.objects.all()[:200],
        'can_add': request.user.has_perm('procurement.add_evaluationitem'),
    })