from django import forms
from .models import (
    ProcurementPlan, ProcurementRequirement, Requisition,
    Procurement, ProcurementItem, TechnicalSpecification,
    TechnicalEvaluation, EvaluationItem
)
from core.validators import validate_nlc_email


class BootstrapModelForm(forms.ModelForm):
    """Adds Bootstrap classes to every widget automatically."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            if isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs['class'] = 'form-check-input'
            else:
                field.widget.attrs['class'] = 'form-control'


class ProcurementPlanForm(BootstrapModelForm):
    class Meta:
        model = ProcurementPlan
        fields = ['title', 'period_type', 'fiscal_year', 'total_budget', 'justification']


class ProcurementRequirementForm(BootstrapModelForm):
    class Meta:
        model = ProcurementRequirement
        fields = ['plan', 'item_name', 'category', 'quantity', 'estimated_unit_price']


class RequisitionForm(BootstrapModelForm):
    class Meta:
        model = Requisition
        fields = ['requirement']


class SendApprovalEmailForm(forms.Form):
    """Used to email a requisition/contract's approval details to an
    official nlc.com.pk address, from the approval pages."""
    email = forms.EmailField(
        label="Send to (official email)",
        validators=[validate_nlc_email],
        widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'name@nlc.com.pk'})
    )


class ProcurementForm(BootstrapModelForm):
    class Meta:
        model = Procurement
        fields = ['requisition', 'vendor', 'tender_number', 'po_number',
                  'tender_publishing_date', 'total_value']
        widgets = {
            'tender_publishing_date': forms.DateInput(attrs={'type': 'date'}),
        }


class ProcurementItemForm(BootstrapModelForm):
    class Meta:
        model = ProcurementItem
        # total_price is computed automatically in ProcurementItem.save(),
        # so it's deliberately left out of the form.
        fields = ['procurement', 'item_name', 'category', 'quantity', 'unit_price']


class TechnicalSpecificationForm(BootstrapModelForm):
    class Meta:
        model = TechnicalSpecification
        fields = ['procurement_item', 'spec_name', 'required_value', 'mandatory']


class TechnicalEvaluationForm(BootstrapModelForm):
    class Meta:
        model = TechnicalEvaluation
        # evaluated_by and evaluation_date are set automatically in the view.
        fields = ['procurement', 'vendor', 'overall_result', 'remarks']


class EvaluationItemForm(BootstrapModelForm):
    class Meta:
        model = EvaluationItem
        fields = ['evaluation', 'specification', 'offered_value', 'result', 'comments']