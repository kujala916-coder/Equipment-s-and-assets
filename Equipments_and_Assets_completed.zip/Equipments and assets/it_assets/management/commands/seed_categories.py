"""
Adds a set of common IT asset/stock categories so the Category dropdown
has sensible options out of the box, instead of starting empty.

Safe to run any time — existing categories (including any test/demo ones
already in the database) are left untouched; this only ADDS categories
that don't already exist by name.

Usage:
    python manage.py seed_categories
"""
from django.core.management.base import BaseCommand
from it_assets.models import AssetCategory

# name -> code_prefix (used in generated Asset IDs, e.g. IT-LAP-000001)
COMMON_CATEGORIES = {
    "Laptop": "LAP",
    "Desktop": "DSK",
    "Monitor": "MON",
    "Printer": "PRN",
    "USB Drive / Storage": "USB",
    "Keyboard & Mouse": "KBM",
    "Networking Equipment": "NET",
    "Cables & Accessories": "CBL",
    "UPS / Power Backup": "UPS",
    "Projector": "PRJ",
    "Scanner": "SCN",
    "Server": "SRV",
}


class Command(BaseCommand):
    help = "Adds common IT asset categories (Laptop, USB Drive, Printer, etc.) if they don't already exist."

    def handle(self, *args, **options):
        self.stdout.write("Seeding common categories...")
        for name, prefix in COMMON_CATEGORIES.items():
            category, created = AssetCategory.objects.get_or_create(
                name=name,
                defaults={"code_prefix": prefix, "is_active": True},
            )
            status = "created" if created else "already exists"
            self.stdout.write(f"  [{status}] {name}")
        self.stdout.write(self.style.SUCCESS("Done."))
