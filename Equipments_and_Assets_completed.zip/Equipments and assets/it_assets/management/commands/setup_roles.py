"""
setup_roles
============
Creates the 4 role-based Groups (Procurement, Inventory Store,
IT Equipment Manager, Help Desk) with the correct Django permissions,
and optionally creates one demo user per role so the demo can be
shown immediately.

Usage:
    python manage.py setup_roles
    python manage.py setup_roles --with-demo-users
    python manage.py setup_roles --with-demo-users --password Demo@12345

The Admin role is just a Django superuser — create it separately with:
    python manage.py createsuperuser
"""

from django.contrib.auth import get_user_model
from django.contrib.auth.models import Group, Permission
from django.contrib.contenttypes.models import ContentType
from django.core.management.base import BaseCommand

User = get_user_model()


def perms_for(app_label, model_names, actions=("view", "add", "change", "delete")):
    """Return Permission objects for given model names in an app, for the given actions."""
    perms = []
    for model_name in model_names:
        try:
            ct = ContentType.objects.get(app_label=app_label, model=model_name.lower())
        except ContentType.DoesNotExist:
            continue
        for action in actions:
            codename = f"{action}_{model_name.lower()}"
            try:
                perms.append(Permission.objects.get(content_type=ct, codename=codename))
            except Permission.DoesNotExist:
                pass
    return perms


# ---------------------------------------------------------------------------
# Role -> (app_label, [model names], allowed actions) definitions
# ---------------------------------------------------------------------------
ROLE_DEFINITIONS = {
    "Procurement": [
        ("procurement", [
            "ProcurementPlan", "ProcurementRequirement", "Requisition",
            "Procurement", "ProcurementItem", "TechnicalSpecification",
            "TechnicalEvaluation", "EvaluationItem",
        ], ("view", "add", "change", "delete")),
        ("vendors", [
            "Vendor", "VendorContact", "VendorPerformance",
            "VendorIssue", "VendorEscalation",
        ], ("view", "add", "change", "delete")),
        ("contracts", [
            "Contract", "ContractRenewal", "License", "SLA",
        ], ("view", "add", "change", "delete")),
        # Asset Categories are master data shared across every role (used
        # when picking a category for requirements/items) — view-only here.
        ("it_assets", ["AssetCategory"], ("view",)),
        ("notifications", ["Notification"], ("view",)),
    ],
    "Inventory Store": [
        ("it_assets", [
            "Asset", "AssetCategory", "Employee",
            "StockItem", "GoodsReceipt", "GoodsReceiptItem", "StockTransaction",
            "EquipmentIssue", "EquipmentReturn", "AssetTransfer",
            "InventoryVerification", "InventoryVerificationItem",
            "InventoryReconciliation", "AssetTag",
        ], ("view", "add", "change", "delete")),
        ("disposal", ["DisposalRequest"], ("view", "add")),
        ("notifications", ["Notification"], ("view",)),
    ],
    # IT Manager oversees inventory but doesn't do the data entry themselves —
    # view-only across the board, per the real IT Manager's own instruction.
    "IT Equipment Manager": [
        ("it_assets", [
            "Employee", "AssetCategory", "Asset", "StockItem",
            "GoodsReceipt", "GoodsReceiptItem", "StockTransaction",
            "EquipmentIssue", "EquipmentReturn", "AssetTransfer",
            "FaultReport", "RepairRecord", "Warranty", "WarrantyClaim",
            "InventoryVerification", "InventoryVerificationItem",
            "InventoryReconciliation", "AssetTag",
        ], ("view",)),
        ("disposal", ["DisposalRequest"], ("view", "add", "change")),
        ("notifications", ["Notification"], ("view",)),
    ],
    # Help Desk's access is deliberately narrow — just Faults (+ Repair
    # Records, part of the same fault-handling workflow) and Analytics.
    # Analytics needs no model permission (it's login-only), so nothing
    # extra is granted for it here.
    "Help Desk": [
        ("it_assets", ["FaultReport", "RepairRecord"], ("view", "add", "change")),
        # Asset Categories are master data shared across every role — view-only here.
        ("it_assets", ["AssetCategory"], ("view",)),
    ],
    # View-only oversight role: sees Vendor / Procurement / Contract / Notifications
    # but can never add, change, or delete anything in those areas.
    "Manager": [
        # View-only — Manager can see Inventory's world but never touch it.
        ("it_assets", [
            "Asset", "AssetCategory", "StockItem", "Employee",
            "EquipmentIssue", "FaultReport",
        ], ("view",)),
        # Full edit — Manager actually owns Vendor / Procurement / Contract / License.
        ("vendors", ["Vendor", "VendorIssue"], ("view", "add", "change")),
        ("vendors", ["VendorContact", "VendorPerformance", "VendorEscalation"], ("view",)),
        ("procurement", ["Procurement"], ("view", "add", "change")),
        ("procurement", [
            "ProcurementPlan", "ProcurementRequirement", "Requisition",
            "ProcurementItem", "TechnicalSpecification",
            "TechnicalEvaluation", "EvaluationItem",
        ], ("view",)),
        ("contracts", ["Contract", "License"], ("view", "add", "change")),
        ("contracts", ["ContractRenewal", "SLA"], ("view",)),
        ("disposal", ["DisposalRequest"], ("view", "change")),
        ("notifications", ["Notification"], ("view",)),
    ],
}

# username -> (group name, first/last name, is_staff so they can use /admin/ login form)
DEMO_USERS = {
    "procurement_user": "Procurement",
    "inventory_user": "Inventory Store",
    "it_manager_user": "IT Equipment Manager",
    "helpdesk_user": "Help Desk",
    "manager_user": "Manager",
}


class Command(BaseCommand):
    help = "Creates role-based Groups with permissions, and optionally demo users for each role."

    def add_arguments(self, parser):
        parser.add_argument(
            "--with-demo-users", action="store_true",
            help="Also create one demo login per role (username shown below, password from --password).",
        )
        parser.add_argument(
            "--password", default="Demo@12345",
            help="Password to set for demo users (default: Demo@12345).",
        )

    def handle(self, *args, **options):
        self.stdout.write("Setting up role groups and permissions...\n")

        for group_name, rules in ROLE_DEFINITIONS.items():
            group, created = Group.objects.get_or_create(name=group_name)
            all_perms = []
            for app_label, model_names, actions in rules:
                all_perms.extend(perms_for(app_label, model_names, actions))
            group.permissions.set(all_perms)
            status = "created" if created else "updated"
            self.stdout.write(self.style.SUCCESS(
                f"  [{status}] '{group_name}' -> {len(all_perms)} permissions"
            ))

        if options["with_demo_users"]:
            self.stdout.write("\nCreating demo users...\n")
            password = options["password"]
            for username, group_name in DEMO_USERS.items():
                user, created = User.objects.get_or_create(username=username)
                user.set_password(password)
                user.save()
                group = Group.objects.get(name=group_name)
                user.groups.set([group])
                action = "created" if created else "updated"
                self.stdout.write(self.style.SUCCESS(
                    f"  [{action}] {username}  (role: {group_name})  password: {password}"
                ))

            self.stdout.write(self.style.WARNING(
                "\nThese are demo credentials only — change/remove them before real deployment.\n"
                "Log in at /login/ with the username/password above.\n"
                "Admin role = a superuser, create separately with: python manage.py createsuperuser"
            ))

        self.stdout.write(self.style.SUCCESS("\nDone."))
