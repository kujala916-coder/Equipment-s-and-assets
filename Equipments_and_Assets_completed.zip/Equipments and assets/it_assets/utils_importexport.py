"""
Generic Import/Export utilities.

To add a new model to Import/Export:
1. Add an entry to _lazy_registry() below with the model, a label, the list
   of field names to include, and (if any) fk_lookup mapping each ForeignKey
   field name to (RelatedModel, "natural_key_field") — e.g. look up a Vendor
   by its "name" instead of its internal database ID.
2. Add its key to REGISTRY_KEYS_ORDER so it shows up on the Import/Export page.
"""
import csv
import io
from datetime import date, datetime
from decimal import Decimal

from django.http import HttpResponse

import openpyxl
from openpyxl.utils import get_column_letter


def _lazy_registry():
    from it_assets.models import Employee, AssetCategory, Asset, StockItem
    from vendors.models import Vendor
    from contracts.models import Contract, License, SLA

    return {
        "employees": dict(
            model=Employee,
            label="Employees",
            fields=["hr_number", "full_name", "department", "designation", "phone", "email", "is_active"],
        ),
        "asset_categories": dict(
            model=AssetCategory,
            label="Asset Categories",
            fields=["name", "code_prefix", "description", "is_active"],
        ),
        "assets": dict(
            model=Asset,
            label="Assets",
            fields=[
                "asset_id", "category", "brand", "model", "serial_number", "vendor",
                "purchase_date", "cost", "warranty_start", "warranty_end", "location",
                "status", "assigned_to", "current_department", "remarks",
            ],
            fk_lookup={
                "category": (AssetCategory, "name"),
                "vendor": (Vendor, "name"),
                "assigned_to": (Employee, "hr_number"),
            },
        ),
        "stock_items": dict(
            model=StockItem,
            label="Stock Items",
            fields=["category", "name", "unit", "is_critical"],
            fk_lookup={"category": (AssetCategory, "name")},
        ),
        "vendors": dict(
            model=Vendor,
            label="Vendors",
            fields=["name", "registration_number", "address", "email", "phone", "status"],
        ),
        "contracts": dict(
            model=Contract,
            label="Contracts",
            fields=[
                "title", "vendor", "contract_type", "contract_number", "start_date",
                "end_date", "value", "status", "notes",
            ],
            fk_lookup={"vendor": (Vendor, "name")},
        ),
        "licenses": dict(
            model=License,
            label="Licenses",
            fields=["contract", "software_name", "license_key", "assigned_to", "expiry_date"],
            fk_lookup={
                "contract": (Contract, "contract_number"),
                "assigned_to": (Asset, "asset_id"),
            },
        ),
        "slas": dict(
            model=SLA,
            label="SLAs",
            fields=["vendor", "title", "uptime_guarantee_percent", "start_date", "end_date", "status", "notes"],
            fk_lookup={"vendor": (Vendor, "name")},
        ),
    }


REGISTRY_KEYS_ORDER = [
    "employees", "asset_categories", "assets", "stock_items",
    "vendors", "contracts", "licenses", "slas",
]


def get_registry():
    return _lazy_registry()


# --- Export -----------------------------------------------------------------

def _display_value(obj, field_name, fk_lookup):
    value = getattr(obj, field_name, None)
    if value is None:
        return ""
    if field_name in (fk_lookup or {}):
        _, lookup_field = fk_lookup[field_name]
        return getattr(value, lookup_field, "") if value else ""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    return value


def export_to_xlsx(config):
    model = config["model"]
    fields = config["fields"]
    fk_lookup = config.get("fk_lookup", {})

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = config["label"][:31]
    ws.append(fields)

    qs = model.objects.all()
    if fk_lookup:
        qs = qs.select_related(*fk_lookup.keys())

    for obj in qs:
        ws.append([_display_value(obj, f, fk_lookup) for f in fields])

    for i, _ in enumerate(fields, start=1):
        ws.column_dimensions[get_column_letter(i)].width = 22

    response = HttpResponse(
        content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )
    filename = config["label"].lower().replace(" ", "_")
    response["Content-Disposition"] = f'attachment; filename="{filename}.xlsx"'
    wb.save(response)
    return response


def export_to_csv(config):
    model = config["model"]
    fields = config["fields"]
    fk_lookup = config.get("fk_lookup", {})

    response = HttpResponse(content_type="text/csv")
    filename = config["label"].lower().replace(" ", "_")
    response["Content-Disposition"] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(fields)

    qs = model.objects.all()
    if fk_lookup:
        qs = qs.select_related(*fk_lookup.keys())

    for obj in qs:
        writer.writerow([_display_value(obj, f, fk_lookup) for f in fields])

    return response


# --- Import -------------------------------------------------------------

def _parse_value(model, field_name, raw_value, fk_lookup):
    if raw_value in (None, ""):
        return None

    if field_name in (fk_lookup or {}):
        related_model, lookup_field = fk_lookup[field_name]
        try:
            return related_model.objects.get(**{lookup_field: str(raw_value).strip()})
        except related_model.DoesNotExist:
            raise ValueError(
                f"No {related_model.__name__} found with {lookup_field}='{raw_value}'"
            )

    field = model._meta.get_field(field_name)
    internal_type = field.get_internal_type()

    if internal_type == "BooleanField":
        if isinstance(raw_value, bool):
            return raw_value
        return str(raw_value).strip().lower() in ("true", "1", "yes", "y")
    if internal_type == "DateField":
        if isinstance(raw_value, datetime):
            return raw_value.date()
        if isinstance(raw_value, date):
            return raw_value
        return datetime.strptime(str(raw_value).strip()[:10], "%Y-%m-%d").date()
    if internal_type == "DateTimeField":
        if isinstance(raw_value, datetime):
            return raw_value
        return datetime.strptime(str(raw_value).strip(), "%Y-%m-%d %H:%M:%S")
    if internal_type == "DecimalField":
        return Decimal(str(raw_value))
    if internal_type in ("IntegerField", "PositiveIntegerField", "SmallIntegerField"):
        return int(raw_value)

    return str(raw_value).strip()


def import_from_rows(config, header, rows):
    """Returns (created_count, updated_count, errors[list of (row_number, message)])."""
    model = config["model"]
    fields = config["fields"]
    fk_lookup = config.get("fk_lookup", {})

    unique_field = None
    for f in fields:
        try:
            mf = model._meta.get_field(f)
            if getattr(mf, "unique", False):
                unique_field = f
                break
        except Exception:
            continue

    header_index = {str(h).strip().lower(): i for i, h in enumerate(header)}
    created, updated = 0, 0
    errors = []

    for row_num, row in enumerate(rows, start=2):  # row 1 is the header
        if row is None or all(v in (None, "") for v in row):
            continue
        try:
            values = {}
            for f in fields:
                if f.lower() not in header_index:
                    continue
                idx = header_index[f.lower()]
                raw = row[idx] if idx < len(row) else None
                values[f] = _parse_value(model, f, raw, fk_lookup)

            for f in fields:
                mf = model._meta.get_field(f)
                is_required = not getattr(mf, "null", True) and not getattr(mf, "blank", True)
                if is_required and values.get(f) in (None, ""):
                    raise ValueError(
                        f"'{f}' column is missing or empty in the file, but it's required."
                    )

            if unique_field and values.get(unique_field) not in (None, ""):
                obj, was_created = model.objects.update_or_create(
                    **{unique_field: values[unique_field]},
                    defaults={k: v for k, v in values.items() if k != unique_field},
                )
                created += int(was_created)
                updated += int(not was_created)
            else:
                model.objects.create(**values)
                created += 1
        except Exception as e:
            errors.append((row_num, str(e)))

    return created, updated, errors


def read_uploaded_file(uploaded_file):
    """Returns (header, rows) from an uploaded .xlsx or .csv file."""
    name = uploaded_file.name.lower()
    if name.endswith(".xlsx"):
        wb = openpyxl.load_workbook(uploaded_file, data_only=True)
        ws = wb.active
        rows_iter = ws.iter_rows(values_only=True)
        header = [str(h) if h is not None else "" for h in next(rows_iter)]
        rows = [list(r) for r in rows_iter]
        return header, rows
    elif name.endswith(".csv"):
        text = uploaded_file.read().decode("utf-8-sig")
        reader = csv.reader(io.StringIO(text))
        all_rows = list(reader)
        if not all_rows:
            return [], []
        return all_rows[0], all_rows[1:]
    else:
        raise ValueError("Unsupported file type. Please upload a .xlsx or .csv file.")
