IMPORT_EXPORT_ALLOWED_GROUPS = {"Manager", "Inventory Store"}


def import_export_access(request):
    """Makes `can_use_import_export` available in every template (used by
    the main nav) without every view having to pass it explicitly."""
    user = getattr(request, "user", None)
    can_use = bool(
        user and user.is_authenticated and (
            user.is_superuser or user.groups.filter(name__in=IMPORT_EXPORT_ALLOWED_GROUPS).exists()
        )
    )
    return {"can_use_import_export": can_use}
