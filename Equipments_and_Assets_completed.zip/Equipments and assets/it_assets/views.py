from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied
from django.db.models import F, Q, Count
from django.http import Http404
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
from datetime import timedelta

from . import utils_importexport as ie
from .models import (
    Employee, Asset, AssetCategory, StockItem,
    GoodsReceipt, GoodsReceiptItem,
    EquipmentIssue, EquipmentReturn, AssetTransfer,
    FaultReport, RepairRecord,
    InventoryVerification, InventoryVerificationItem, InventoryReconciliation,
)
from .forms import (
    EmployeeForm, AssetForm, AssetCategoryForm, StockItemForm,
    GoodsReceiptForm, GoodsReceiptFromPOForm, GoodsReceiptItemForm,
    EquipmentIssueForm, EquipmentReturnForm, AssetTransferForm,
    FaultReportForm, RepairRecordForm,
    InventoryVerificationForm, InventoryVerificationItemForm, InventoryReconciliationForm,
)


# ---------------------------------------------------------------------------
# Dashboard — combined view across all merged apps
# ---------------------------------------------------------------------------
@login_required
def dashboard(request):
    context = {
        # --- Asset & Store (Phase 1) ---
        "total_assets": Asset.objects.count(),
        "assets_in_stock": Asset.objects.filter(status=Asset.Status.IN_STOCK).count(),
        "assets_assigned": Asset.objects.filter(status=Asset.Status.ASSIGNED).count(),
        "assets_under_repair": Asset.objects.filter(status=Asset.Status.UNDER_REPAIR).count(),
        "low_stock_items": StockItem.objects.filter(quantity_available__lte=F("reorder_level")),
        # --- Fault / Repair (Phase 3) ---
        "open_faults": FaultReport.objects.exclude(status=FaultReport.Status.CLOSED).count(),
    }

    # --- Vendors (teammate's app) ---
    try:
        from vendors.models import Vendor, VendorIssue
        context["total_vendors"] = Vendor.objects.count()
        context["active_vendors"] = Vendor.objects.filter(status="active").count()
        context["open_vendor_issues"] = VendorIssue.objects.filter(status__in=["open", "in_progress"]).count()
    except Exception:
        pass

    # --- Procurement (teammate's app) ---
    try:
        from procurement.models import Requisition, Procurement
        context["pending_requisitions"] = Requisition.objects.filter(status="pending").count()
        context["procurements_in_progress"] = Procurement.objects.exclude(
            status__in=["closed", "cancelled"]
        ).count()
    except Exception:
        pass

    # --- Contracts (teammate's app) ---
    try:
        from contracts.models import Contract
        soon = timezone.now().date() + timedelta(days=30)
        context["active_contracts"] = Contract.objects.filter(status="active").count()
        context["contracts_expiring_soon"] = Contract.objects.filter(
            status="active", end_date__lte=soon, end_date__gte=timezone.now().date()
        ).count()
    except Exception:
        pass

    # --- Notifications (teammate's app) ---
    try:
        from notifications.models import Notification
        context["recent_notifications"] = Notification.objects.filter(
            recipient=request.user
        ).order_by("-created_at")[:5]
    except Exception:
        pass

    # --- Audit Log (teammate's app) ---
    try:
        from audit.models import AuditLog
        context["recent_audit_logs"] = AuditLog.objects.order_by("-timestamp")[:5]
    except Exception:
        pass

    return render(request, "it_assets/dashboard.html", context)


# ---------------------------------------------------------------------------
# Employee (asset custody tracking)
# ---------------------------------------------------------------------------
@login_required
@permission_required("it_assets.view_employee", raise_exception=True)
def employee_list(request):
    employees = Employee.objects.all()
    return render(request, "it_assets/employee_list.html", {"employees": employees})


@login_required
@permission_required("it_assets.add_employee", raise_exception=True)
def employee_create(request):
    form = EmployeeForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        employee = form.save()
        messages.success(request, f"Employee {employee.full_name} added.")
        return redirect("it_assets:employee_list")
    return render(request, "it_assets/employee_form.html", {"form": form})


@login_required
@permission_required("it_assets.view_employee", raise_exception=True)
def employee_detail(request, pk):
    employee = get_object_or_404(Employee, pk=pk)
    return render(request, "it_assets/employee_detail.html", {
        "employee": employee,
        "assets_held": employee.assigned_assets.all(),
        "issues": employee.equipment_received.select_related("asset").all(),
        "transfers_in": employee.transfers_in.select_related("asset").all(),
        "transfers_out": employee.transfers_out.select_related("asset").all(),
    })


# ---------------------------------------------------------------------------
# Asset Category
# ---------------------------------------------------------------------------
@login_required
@permission_required("it_assets.view_assetcategory", raise_exception=True)
def category_list(request):
    query = request.GET.get("q", "").strip()
    categories = AssetCategory.objects.select_related("parent").all()
    if query:
        categories = categories.filter(
            Q(name__icontains=query)
            | Q(code_prefix__icontains=query)
            | Q(description__icontains=query)
        )
    return render(request, "it_assets/category_list.html", {
        "categories": categories,
        "query": query,
    })


@login_required
@permission_required("it_assets.add_assetcategory", raise_exception=True)
def category_create(request):
    form = AssetCategoryForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Category created.")
        return redirect("it_assets:category_list")
    return render(request, "it_assets/category_form.html", {"form": form})


@login_required
@permission_required("it_assets.add_assetcategory", raise_exception=True)
def category_quick_add(request):
    """Lets a user add a new Asset Category without leaving whatever form
    they're filling out (Asset/Stock/etc.) — used by the '+ New' button
    next to the category dropdown."""
    from django.http import JsonResponse
    if request.method != "POST":
        return JsonResponse({"error": "POST required"}, status=405)
    name = request.POST.get("name", "").strip()
    if not name:
        return JsonResponse({"error": "Name is required"}, status=400)
    category, created = AssetCategory.objects.get_or_create(name=name)
    return JsonResponse({"id": category.id, "name": category.name, "created": created})


# ---------------------------------------------------------------------------
# Asset
# ---------------------------------------------------------------------------
@login_required
@permission_required("it_assets.view_asset", raise_exception=True)
def asset_list(request):
    assets = Asset.objects.select_related("category", "assigned_to").annotate(
        repair_count=Count("fault_reports__repair_records", distinct=True)
    )
    status_filter = request.GET.get("status")
    if status_filter:
        assets = assets.filter(status=status_filter)
    query = request.GET.get("q", "").strip()
    if query:
        assets = assets.filter(
            Q(asset_id__icontains=query)
            | Q(brand__icontains=query)
            | Q(model__icontains=query)
            | Q(serial_number__icontains=query)
            | Q(assigned_to__full_name__icontains=query)
            | Q(assigned_to__hr_number__icontains=query)
            | Q(current_department__icontains=query)
        )
    return render(request, "it_assets/asset_list.html", {
        "assets": assets,
        "status_choices": Asset.Status.choices,
        "current_status": status_filter,
        "query": query,
    })


@login_required
@permission_required("it_assets.view_asset", raise_exception=True)
def asset_detail(request, pk):
    asset = get_object_or_404(Asset, pk=pk)
    return render(request, "it_assets/asset_detail.html", {
        "asset": asset,
        "issues": asset.issues.select_related("issued_to").all(),
        "transfers": asset.transfers.all(),
        "fault_reports": asset.fault_reports.all(),
    })


@login_required
@permission_required("it_assets.add_asset", raise_exception=True)
def asset_create(request):
    form = AssetForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        asset = form.save()
        messages.success(request, f"Asset {asset.asset_id} registered.")
        return redirect("it_assets:asset_detail", pk=asset.pk)
    return render(request, "it_assets/asset_form.html", {"form": form})


@login_required
@permission_required("it_assets.change_asset", raise_exception=True)
def asset_update(request, pk):
    asset = get_object_or_404(Asset, pk=pk)
    form = AssetForm(request.POST or None, instance=asset)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, f"Asset {asset.asset_id} updated.")
        return redirect("it_assets:asset_detail", pk=asset.pk)
    return render(request, "it_assets/asset_form.html", {"form": form, "asset": asset})


# ---------------------------------------------------------------------------
# Stock Items
# ---------------------------------------------------------------------------
@login_required
@permission_required("it_assets.view_stockitem", raise_exception=True)
def stock_list(request):
    items = StockItem.objects.select_related("category").all()
    return render(request, "it_assets/stock_list.html", {"items": items})


@login_required
@permission_required("it_assets.add_stockitem", raise_exception=True)
def stock_create(request):
    form = StockItemForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Stock item created.")
        return redirect("it_assets:stock_list")
    return render(request, "it_assets/stock_form.html", {"form": form})


@login_required
@permission_required("it_assets.change_stockitem", raise_exception=True)
def stock_update(request, pk):
    item = get_object_or_404(StockItem, pk=pk)
    form = StockItemForm(request.POST or None, instance=item)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Stock item updated.")
        return redirect("it_assets:stock_list")
    return render(request, "it_assets/stock_form.html", {"form": form, "item": item})


@login_required
@permission_required("it_assets.delete_stockitem", raise_exception=True)
def stock_delete(request, pk):
    item = get_object_or_404(StockItem, pk=pk)
    if request.method == "POST":
        name = str(item)
        item.delete()
        messages.success(request, f"Stock item '{name}' deleted.")
        return redirect("it_assets:stock_list")
    return render(request, "it_assets/stock_confirm_delete.html", {"item": item})


@login_required
@permission_required("it_assets.view_stockitem", raise_exception=True)
def stock_report_fault(request, pk):
    """Lets store staff raise a FaultReport directly against a stock item
    (previously faults could only be logged against a deployed Asset)."""
    item = get_object_or_404(StockItem, pk=pk)
    if request.method == "POST":
        form = FaultReportForm(request.POST)
        form.fields["asset"].required = False
        if form.is_valid():
            fault = form.save(commit=False)
            fault.reported_by = request.user
            fault.stock_item = item
            fault.save()
            messages.success(request, f"Fault reported against stock item '{item}'.")
            return redirect("it_assets:stock_list")
    else:
        form = FaultReportForm()
        form.fields["asset"].required = False
    return render(request, "it_assets/fault_report_form.html", {"form": form, "stock_item": item})


# ---------------------------------------------------------------------------
# Goods Receipt
# ---------------------------------------------------------------------------
@login_required
@permission_required("it_assets.add_goodsreceipt", raise_exception=True)
def goods_receipt_create(request):
    """Pick a Purchase Order — vendor and every item on it are fetched
    automatically and the full receipt is generated in one go, the way a
    store hands you a receipt at checkout instead of you writing it yourself."""
    form = GoodsReceiptFromPOForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        procurement = form.cleaned_data["procurement"]
        if not procurement.vendor_id:
            messages.error(request, "This PO has no vendor set, so a receipt can't be generated from it.")
            return render(request, "it_assets/goods_receipt_form.html", {"form": form})

        receipt = GoodsReceipt.objects.create(
            vendor=procurement.vendor,
            procurement=procurement,
            po_reference=procurement.po_number or procurement.tender_number or "",
            delivery_date=form.cleaned_data["delivery_date"],
            inspection_remarks=form.cleaned_data["inspection_remarks"],
            received_by=request.user,
        )

        created_count = 0
        skipped = []
        for po_item in procurement.items.all():
            if not po_item.category_id:
                # No category on the PO item — can't create a GoodsReceiptItem
                # (category is required), so leave it for manual add.
                skipped.append(po_item.item_name)
                continue
            item = GoodsReceiptItem.objects.create(
                receipt=receipt,
                category=po_item.category,
                description=po_item.item_name,
                quantity_received=po_item.quantity,
                quantity_accepted=po_item.quantity,
                quantity_rejected=0,
                is_serialized=False,
                serial_numbers="",
            )
            item.create_downstream_records(vendor=procurement.vendor, received_date=receipt.delivery_date)
            created_count += 1

        if skipped:
            messages.warning(
                request,
                f"Receipt {receipt.grn_number} generated with {created_count} item(s) fetched from the PO. "
                f"{len(skipped)} item(s) without a category ({', '.join(skipped)}) were skipped — add them manually below."
            )
        else:
            messages.success(
                request,
                f"Receipt {receipt.grn_number} generated automatically with {created_count} item(s) from the PO."
            )
        return redirect("it_assets:goods_receipt_detail", pk=receipt.pk)
    return render(request, "it_assets/goods_receipt_form.html", {"form": form})


@login_required
@permission_required("it_assets.add_goodsreceipt", raise_exception=True)
def goods_receipt_create_manual(request):
    """Fallback for receipts that aren't tied to a PO in the system —
    everything is typed in by hand, item by item."""
    form = GoodsReceiptForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        receipt = form.save(commit=False)
        receipt.received_by = request.user
        receipt.save()
        messages.success(request, f"Goods receipt {receipt.grn_number} created. Now add items.")
        return redirect("it_assets:goods_receipt_add_item", pk=receipt.pk)
    return render(request, "it_assets/goods_receipt_form_manual.html", {"form": form})


@login_required
@permission_required("it_assets.add_goodsreceiptitem", raise_exception=True)
def goods_receipt_add_item(request, pk):
    receipt = get_object_or_404(GoodsReceipt, pk=pk)
    form = GoodsReceiptItemForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        item = form.save(commit=False)
        item.receipt = receipt
        item.full_clean()
        item.save()
        item.create_downstream_records(vendor=receipt.vendor, received_date=receipt.delivery_date)
        messages.success(
            request,
            f"Item added and stock/asset records created. Receipt {receipt.grn_number} has been "
            "generated below — add another item, or print it as-is."
        )
        return redirect("it_assets:goods_receipt_detail", pk=receipt.pk)
    return render(request, "it_assets/goods_receipt_item_form.html", {"form": form, "receipt": receipt})


@login_required
@permission_required("it_assets.view_goodsreceipt", raise_exception=True)
def goods_receipt_detail(request, pk):
    receipt = get_object_or_404(GoodsReceipt, pk=pk)
    items = receipt.items.all()
    return render(request, "it_assets/goods_receipt_detail.html", {
        "receipt": receipt,
        "items": items,
        "total_accepted": sum(i.quantity_accepted for i in items),
        "total_rejected": sum(i.quantity_rejected for i in items),
    })


# ---------------------------------------------------------------------------
# Equipment Issue / Return / Transfer
# ---------------------------------------------------------------------------
@login_required
@permission_required("it_assets.add_equipmentissue", raise_exception=True)
def issue_create(request):
    form = EquipmentIssueForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        issue = form.save(commit=False)
        issue.issued_by = request.user
        issue.full_clean()
        issue.save()
        messages.success(request, "Equipment issued.")
        return redirect("it_assets:issue_list")
    return render(request, "it_assets/issue_form.html", {"form": form})


@login_required
@permission_required("it_assets.view_equipmentissue", raise_exception=True)
def issue_list(request):
    issues = EquipmentIssue.objects.select_related("asset", "stock_item", "issued_to").all()
    return render(request, "it_assets/issue_list.html", {"issues": issues})


@login_required
@permission_required("it_assets.add_equipmentreturn", raise_exception=True)
def return_create(request, issue_pk):
    issue = get_object_or_404(EquipmentIssue, pk=issue_pk)
    form = EquipmentReturnForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        ret = form.save(commit=False)
        ret.issue = issue
        ret.received_by = request.user
        ret.save()
        messages.success(request, "Return recorded.")
        return redirect("it_assets:issue_list")
    return render(request, "it_assets/return_form.html", {"form": form, "issue": issue})


@login_required
@permission_required("it_assets.add_assettransfer", raise_exception=True)
def transfer_create(request):
    form = AssetTransferForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        transfer = form.save(commit=False)
        transfer.from_employee = transfer.asset.assigned_to
        transfer.from_department = transfer.asset.current_department
        transfer.from_location = transfer.asset.location
        transfer.approved_by = request.user
        transfer.save()
        messages.success(request, "Asset transferred.")
        return redirect("it_assets:asset_detail", pk=transfer.asset.pk)
    return render(request, "it_assets/transfer_form.html", {"form": form})


# ---------------------------------------------------------------------------
# PHASE 3 — Fault Reporting & Repair Tracking
# ---------------------------------------------------------------------------
@login_required
@permission_required("it_assets.view_faultreport", raise_exception=True)
def fault_report_list(request):
    faults = FaultReport.objects.select_related("asset", "reported_by").all()
    status_filter = request.GET.get("status")
    if status_filter:
        faults = faults.filter(status=status_filter)
    return render(request, "it_assets/fault_report_list.html", {
        "faults": faults,
        "status_choices": FaultReport.Status.choices,
        "current_status": status_filter,
    })


@login_required
@permission_required("it_assets.add_faultreport", raise_exception=True)
def fault_report_create(request):
    initial = {}
    asset_id = request.GET.get("asset")
    if asset_id:
        initial["asset"] = asset_id
    form = FaultReportForm(request.POST or None, initial=initial)
    if request.method == "POST" and form.is_valid():
        fault = form.save(commit=False)
        fault.reported_by = request.user
        fault.save()
        messages.success(request, "Fault reported. Asset marked as under repair.")
        return redirect("it_assets:fault_report_detail", pk=fault.pk)
    return render(request, "it_assets/fault_report_form.html", {"form": form})


@login_required
@permission_required("it_assets.view_faultreport", raise_exception=True)
def fault_report_detail(request, pk):
    fault = get_object_or_404(FaultReport, pk=pk)
    return render(request, "it_assets/fault_report_detail.html", {
        "fault": fault,
        "repairs": fault.repair_records.all(),
    })


@login_required
@permission_required("it_assets.add_repairrecord", raise_exception=True)
def repair_record_create(request, fault_pk):
    fault = get_object_or_404(FaultReport, pk=fault_pk)
    form = RepairRecordForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        repair = form.save(commit=False)
        repair.fault_report = fault
        repair.save()
        messages.success(request, "Repair record saved.")
        return redirect("it_assets:fault_report_detail", pk=fault.pk)
    return render(request, "it_assets/repair_record_form.html", {"form": form, "fault": fault})


@login_required
@permission_required("it_assets.change_repairrecord", raise_exception=True)
def repair_record_update(request, pk):
    repair = get_object_or_404(RepairRecord, pk=pk)
    form = RepairRecordForm(request.POST or None, instance=repair)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Repair record updated.")
        return redirect("it_assets:fault_report_detail", pk=repair.fault_report.pk)
    return render(request, "it_assets/repair_record_form.html", {"form": form, "fault": repair.fault_report, "repair": repair})


# ---------------------------------------------------------------------------
# PHASE 4 — Physical Verification & Asset Tagging
# ---------------------------------------------------------------------------
@login_required
@permission_required("it_assets.view_inventoryverification", raise_exception=True)
def verification_list(request):
    verifications = InventoryVerification.objects.select_related("conducted_by").all()
    return render(request, "it_assets/verification_list.html", {"verifications": verifications})


@login_required
@permission_required("it_assets.add_inventoryverification", raise_exception=True)
def verification_create(request):
    form = InventoryVerificationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        verification = form.save(commit=False)
        verification.conducted_by = request.user
        verification.save()
        messages.success(request, "Verification session started.")
        return redirect("it_assets:verification_detail", pk=verification.pk)
    return render(request, "it_assets/verification_form.html", {"form": form})


@login_required
@permission_required("it_assets.view_inventoryverification", raise_exception=True)
def verification_detail(request, pk):
    verification = get_object_or_404(InventoryVerification, pk=pk)
    return render(request, "it_assets/verification_detail.html", {
        "verification": verification,
        "items": verification.items.select_related("asset", "stock_item").all(),
        "reconciliations": verification.reconciliations.select_related("stock_item").all(),
    })


@login_required
@permission_required("it_assets.add_inventoryverificationitem", raise_exception=True)
def verification_add_item(request, pk):
    verification = get_object_or_404(InventoryVerification, pk=pk)
    form = InventoryVerificationItemForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        item = form.save(commit=False)
        item.verification = verification
        item.full_clean()
        item.save()
        messages.success(request, "Item recorded.")
        return redirect("it_assets:verification_detail", pk=verification.pk)
    return render(request, "it_assets/verification_item_form.html", {"form": form, "verification": verification})


@login_required
@permission_required("it_assets.add_inventoryreconciliation", raise_exception=True)
def verification_add_reconciliation(request, pk):
    verification = get_object_or_404(InventoryVerification, pk=pk)
    form = InventoryReconciliationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        rec = form.save(commit=False)
        rec.verification = verification
        rec.save()
        messages.success(request, "Reconciliation recorded.")
        return redirect("it_assets:verification_detail", pk=verification.pk)
    return render(request, "it_assets/reconciliation_form.html", {"form": form, "verification": verification})


@login_required
@permission_required("it_assets.change_inventoryverification", raise_exception=True)
def verification_complete(request, pk):
    verification = get_object_or_404(InventoryVerification, pk=pk)
    verification.status = InventoryVerification.Status.COMPLETED
    verification.save(update_fields=["status"])
    messages.success(request, "Verification marked as completed.")
    return redirect("it_assets:verification_detail", pk=verification.pk)


@login_required
@permission_required("it_assets.view_asset", raise_exception=True)
def asset_qr_code(request, pk):
    """Generate a QR code image on-the-fly for an asset (encodes the asset detail URL)."""
    from django.http import HttpResponse
    import io

    asset = get_object_or_404(Asset, pk=pk)

    try:
        import qrcode
    except ImportError:
        return HttpResponse(
            "The 'qrcode' package is not installed.\nRun: pip install qrcode[pil]",
            content_type="text/plain", status=501,
        )

    data = request.build_absolute_uri(
        f"/assets/{asset.pk}/"
    )
    img = qrcode.make(data)
    buffer = io.BytesIO()
    img.save(buffer, format="PNG")
    return HttpResponse(buffer.getvalue(), content_type="image/png")


IMPORT_EXPORT_ALLOWED_GROUPS = {"Manager", "Inventory Store"}


def _can_use_import_export(user):
    """Import/Export is reserved for the Manager and Inventory Store roles
    only — not a general feature unlocked by per-model permissions."""
    return user.is_superuser or user.groups.filter(name__in=IMPORT_EXPORT_ALLOWED_GROUPS).exists()


@login_required
def import_export_home(request):
    if not _can_use_import_export(request.user):
        raise PermissionDenied("Import/Export is only available to Manager and Inventory Store accounts.")
    registry = ie.get_registry()
    items = []
    for key in ie.REGISTRY_KEYS_ORDER:
        if key not in registry:
            continue
        config = registry[key]
        model = config["model"]
        app_label = model._meta.app_label
        model_name = model._meta.model_name
        can_view = request.user.has_perm(f"{app_label}.view_{model_name}")
        can_import = (
            request.user.has_perm(f"{app_label}.add_{model_name}")
            and request.user.has_perm(f"{app_label}.change_{model_name}")
        )
        if not can_view and not can_import:
            continue  # nothing this user is allowed to do with this data — don't even list it
        items.append((key, config["label"], can_view, can_import))
    return render(request, "it_assets/import_export.html", {"items": items})


@login_required
def export_model(request, model_key, file_format):
    if not _can_use_import_export(request.user):
        raise PermissionDenied("Import/Export is only available to Manager and Inventory Store accounts.")
    registry = ie.get_registry()
    config = registry.get(model_key)
    if not config:
        raise Http404("Unknown model")
    model = config["model"]
    perm = f"{model._meta.app_label}.view_{model._meta.model_name}"
    if not request.user.has_perm(perm):
        raise PermissionDenied("You don't have permission to export this data.")
    if file_format == "xlsx":
        return ie.export_to_xlsx(config)
    elif file_format == "csv":
        return ie.export_to_csv(config)
    raise Http404("Unknown format")


@login_required
def import_model(request, model_key):
    if not _can_use_import_export(request.user):
        raise PermissionDenied("Import/Export is only available to Manager and Inventory Store accounts.")
    registry = ie.get_registry()
    config = registry.get(model_key)
    if not config:
        raise Http404("Unknown model")
    model = config["model"]
    app_label = model._meta.app_label
    model_name = model._meta.model_name
    if not (request.user.has_perm(f"{app_label}.add_{model_name}")
            and request.user.has_perm(f"{app_label}.change_{model_name}")):
        raise PermissionDenied("You don't have permission to import this data.")

    if request.method == "POST" and request.FILES.get("file"):
        uploaded = request.FILES["file"]
        try:
            header, rows = ie.read_uploaded_file(uploaded)
            created, updated, errors = ie.import_from_rows(config, header, rows)
            if errors:
                error_lines = "; ".join(f"Row {r}: {msg}" for r, msg in errors[:10])
                messages.warning(
                    request,
                    f"{config['label']}: {created} created, {updated} updated, "
                    f"{len(errors)} row(s) failed. First errors — {error_lines}",
                )
            else:
                messages.success(
                    request,
                    f"{config['label']}: {created} created, {updated} updated successfully.",
                )
        except Exception as e:
            messages.error(request, f"Import failed: {e}")
        return redirect("it_assets:import_export_home")

    return render(request, "it_assets/import_model.html", {
        "config": config,
        "model_key": model_key,
    })
