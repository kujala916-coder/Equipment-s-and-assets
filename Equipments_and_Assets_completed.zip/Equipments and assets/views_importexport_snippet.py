# --------------------------------------------------------------------------
# Add these imports near the top of it_assets/views.py:
#
#   from django.http import Http404
#   from . import utils_importexport as ie
#
# Then add these three view functions anywhere in the file (e.g. right
# after the dashboard view):
# --------------------------------------------------------------------------


@login_required
def import_export_home(request):
    registry = ie.get_registry()
    items = [(key, registry[key]["label"]) for key in ie.REGISTRY_KEYS_ORDER if key in registry]
    return render(request, "it_assets/import_export.html", {"items": items})


@login_required
def export_model(request, model_key, file_format):
    registry = ie.get_registry()
    config = registry.get(model_key)
    if not config:
        raise Http404("Unknown model")
    if file_format == "xlsx":
        return ie.export_to_xlsx(config)
    elif file_format == "csv":
        return ie.export_to_csv(config)
    raise Http404("Unknown format")


@login_required
def import_model(request, model_key):
    registry = ie.get_registry()
    config = registry.get(model_key)
    if not config:
        raise Http404("Unknown model")

    if request.method == "POST" and request.FILES.get("file"):
        uploaded = request.FILES["file"]
        try:
            header, rows = ie.read_uploaded_file(uploaded)
            created, updated, errors = ie.import_from_rows(config, header, rows)
            if errors:
                error_lines = "; ".join(f"Row {r}: {msg}" for r, msg in errors[:10])
                messages.warning(
                    request,
                    f"{config['label']}: {created} created, {updated} updated, "
                    f"{len(errors)} row(s) failed. First errors — {error_lines}",
                )
            else:
                messages.success(
                    request,
                    f"{config['label']}: {created} created, {updated} updated successfully.",
                )
        except Exception as e:
            messages.error(request, f"Import failed: {e}")
        return redirect("it_assets:import_export_home")

    return render(request, "it_assets/import_model.html", {
        "config": config,
        "model_key": model_key,
    })
