import re

from django.core.exceptions import ValidationError

# Approval documents may only be emailed to official addresses on the
# organization's own domain (nlc.com.pk) — "example@nlc.com.pk" is just an
# example of the shape, not a literal address to allow.
NLC_EMAIL_PATTERN = re.compile(r'^[^@\s]+@nlc\.com\.pk$', re.IGNORECASE)


def validate_nlc_email(value):
    if not NLC_EMAIL_PATTERN.match(value or ''):
        raise ValidationError(
            "Please enter a valid official email address ending in @nlc.com.pk "
            "(e.g. name@nlc.com.pk)."
        )
