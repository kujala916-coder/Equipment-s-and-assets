from django.urls import path
from . import views

app_name = 'contracts'

urlpatterns = [
    path('', views.contract_list, name='contract_list'),
    path('approvals/', views.contract_approvals, name='contract_approvals'),
    path('approvals/<int:pk>/approve/', views.contract_approve, name='contract_approve'),
    path('approvals/<int:pk>/send-email/', views.contract_send_email, name='contract_send_email'),
    path('renewals/', views.renewal_list, name='renewal_list'),
    path('licenses/', views.license_list, name='license_list'),
    path('licenses/<int:pk>/renew/', views.license_renew, name='license_renew'),
    path('sla/', views.sla_list, name='sla_list'),
    path('sla/<int:pk>/renew/', views.sla_renew, name='sla_renew'),
]