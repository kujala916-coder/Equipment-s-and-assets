from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied
from django.core.mail import send_mail
from django.utils import timezone
from django.utils.http import url_has_allowed_host_and_scheme
from .forms import ContractForm, ContractRenewalForm, LicenseForm, SLAForm, SendApprovalEmailForm
from .models import Contract, ContractRenewal, License, SLA


def _block_post_without_add(request, codename):
    """View-only roles (e.g. Manager) can GET these pages but must never be
    able to submit the form, even though they have view_* permission."""
    if request.method == 'POST' and not request.user.has_perm(codename):
        raise PermissionDenied("You have view-only access and cannot add records.")


@login_required
@permission_required("contracts.view_contract", raise_exception=True)
def contract_list(request):
    _block_post_without_add(request, "contracts.add_contract")
    if request.method == 'POST':
        form = ContractForm(request.POST, request.FILES)
        if form.is_valid():
            contract = form.save(commit=False)
            contract.oic_approval_required = contract.needs_oic_approval()
            if contract.oic_approval_required:
                # A fresh save always starts unapproved; OIC signs off separately.
                contract.oic_approved = False
                contract.oic_approved_by = None
                contract.oic_approved_at = None
            contract.save()
            if contract.oic_approval_required:
                messages.warning(
                    request,
                    f"Contract saved, but it's above Rs. {Contract.OIC_APPROVAL_THRESHOLD:,} "
                    "and is pending OIC approval before it's finalized."
                )
            else:
                messages.success(request, "Contract saved.")
            return redirect('contracts:contract_list')
    else:
        form = ContractForm()

    return render(request, 'contracts/contract_list.html', {
        'form': form, 'form_title': 'Contract', 'objects': form._meta.model.objects.all()[:200], 'is_file_form': True,
        'contracts': Contract.objects.select_related('vendor').all(),
        'oic_threshold': Contract.OIC_APPROVAL_THRESHOLD,
        'can_add': request.user.has_perm('contracts.add_contract'),
    })


@login_required
@permission_required("contracts.view_contract", raise_exception=True)
def contract_approvals(request):
    """List of contracts still waiting on OIC sign-off."""
    pending = Contract.objects.filter(
        oic_approval_required=True, oic_approved=False
    ).order_by('-created_at')
    return render(request, 'contracts/approval_list.html', {'pending': pending})


@login_required
def contract_approve(request, pk):
    """Only the OIC (an Admin/superuser) can approve a high-value contract."""
    if not request.user.is_superuser:
        raise PermissionDenied("Only an OIC/Admin can approve this contract.")
    contract = get_object_or_404(Contract, pk=pk)
    if request.method == 'POST':
        contract.oic_approved = True
        contract.oic_remarks = request.POST.get('remarks', '').strip()
        contract.oic_approved_by = request.user
        contract.oic_approved_at = timezone.now()
        contract.save()
        messages.success(request, f"Contract '{contract.title}' approved.")
        return redirect('contracts:contract_approvals')
    return render(request, 'contracts/approve_form.html', {'contract': contract})


@login_required
@permission_required("contracts.view_contract", raise_exception=True)
def contract_send_email(request, pk):
    """Email a contract's value/vendor and OIC-approval status to an
    official nlc.com.pk address — used from the OIC approval page."""
    contract = get_object_or_404(Contract, pk=pk)
    if request.method == 'POST':
        form = SendApprovalEmailForm(request.POST)
        if form.is_valid():
            to_email = form.cleaned_data['email']
            subject = f"Contract — {contract.title}"
            body_lines = [
                f"Contract: {contract.title}",
                f"Vendor: {contract.vendor}",
                f"Type: {contract.get_contract_type_display()}",
                f"Value: Rs. {contract.value:,.2f}" if contract.value is not None else "Value: —",
                f"Period: {contract.start_date} – {contract.end_date}",
                "",
            ]
            if contract.oic_approval_required:
                body_lines.append(
                    "OIC Approval: " + (
                        f"Approved by {contract.oic_approved_by}" if contract.oic_approved else "Pending"
                    )
                )
            body_lines += ["", f"Sent by {request.user.get_username()} via IT Equipment & Stores Management."]

            send_mail(subject, "\n".join(body_lines), None, [to_email], fail_silently=False)
            messages.success(request, f"Contract '{contract.title}' details emailed to {to_email}.")
        else:
            messages.error(request, "Please enter a valid official email address (e.g. name@nlc.com.pk).")

    referer = request.META.get('HTTP_REFERER')
    if referer and url_has_allowed_host_and_scheme(referer, allowed_hosts={request.get_host()}):
        return redirect(referer)
    return redirect('contracts:contract_approvals')


@login_required
@permission_required("contracts.view_contractrenewal", raise_exception=True)
def renewal_list(request):
    _block_post_without_add(request, "contracts.add_contractrenewal")
    if request.method == 'POST':
        form = ContractRenewalForm(request.POST)
        if form.is_valid():
            renewal = form.save(commit=False)
            if request.user.is_authenticated:
                renewal.renewed_by = request.user
            renewal.save()
            messages.success(request, "Contract renewal saved.")
            return redirect('contracts:renewal_list')
    else:
        form = ContractRenewalForm()

    return render(request, 'contracts/renewal_list.html', {
        'form': form, 'form_title': 'Contract Renewal', 'objects': form._meta.model.objects.all()[:200],
        'renewals': ContractRenewal.objects.select_related('contract', 'renewed_by').all(),
        'can_add': request.user.has_perm('contracts.add_contractrenewal'),
    })


@login_required
@permission_required("contracts.view_license", raise_exception=True)
def license_list(request):
    _block_post_without_add(request, "contracts.add_license")
    if request.method == 'POST':
        form = LicenseForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "License saved.")
            return redirect('contracts:license_list')
    else:
        form = LicenseForm()

    return render(request, 'contracts/license_list.html', {
        'form': form, 'form_title': 'License', 'objects': form._meta.model.objects.all()[:200],
        'licenses': License.objects.select_related('contract', 'assigned_to').all(),
        'can_add': request.user.has_perm('contracts.add_license'),
    })


@login_required
@permission_required("contracts.change_license", raise_exception=True)
def license_renew(request, pk):
    """5.30 — track renewal (here: extend expiry) for an individual license."""
    license_obj = get_object_or_404(License, pk=pk)
    if request.method == 'POST':
        new_expiry = request.POST.get('new_expiry_date')
        if new_expiry:
            license_obj.expiry_date = new_expiry
            license_obj.save(update_fields=['expiry_date'])
            messages.success(request, f"License '{license_obj.software_name}' renewed to {new_expiry}.")
        else:
            messages.error(request, "Please provide a new expiry date.")
    return redirect('contracts:license_list')


@login_required
@permission_required("contracts.view_sla", raise_exception=True)
def sla_list(request):
    """4.40 — vendor SLA terms, service targets and escalation contacts."""
    _block_post_without_add(request, "contracts.add_sla")
    if request.method == 'POST':
        form = SLAForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "SLA saved.")
            return redirect('contracts:sla_list')
    else:
        form = SLAForm()

    return render(request, 'contracts/sla_list.html', {
        'form': form, 'form_title': 'SLA', 'objects': form._meta.model.objects.all()[:200],
        'slas': SLA.objects.select_related('vendor').all(),
        'can_add': request.user.has_perm('contracts.add_sla'),
    })


@login_required
@permission_required("contracts.change_sla", raise_exception=True)
def sla_renew(request, pk):
    """5.30 — renewal date tracking for an SLA (extends end_date, marks renewed)."""
    sla = get_object_or_404(SLA, pk=pk)
    if request.method == 'POST':
        new_end_date = request.POST.get('new_end_date')
        if new_end_date:
            sla.end_date = new_end_date
            sla.status = 'renewed'
            sla.save(update_fields=['end_date', 'status'])
            messages.success(request, f"SLA '{sla.title}' renewed to {new_end_date}.")
        else:
            messages.error(request, "Please provide a new end date.")
    return redirect('contracts:sla_list')