from django.urls import path

from . import views

app_name = 'disposal'

urlpatterns = [
    path('', views.disposal_list, name='disposal_list'),
    path('<int:pk>/', views.disposal_detail, name='disposal_detail'),
    path('<int:pk>/approve/', views.disposal_approve, name='disposal_approve'),
    path('<int:pk>/reject/', views.disposal_reject, name='disposal_reject'),
    path('<int:pk>/finalize/', views.disposal_finalize, name='disposal_finalize'),
]
