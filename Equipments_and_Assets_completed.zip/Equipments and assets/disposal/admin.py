from django.contrib import admin

from .models import DisposalRequest


@admin.register(DisposalRequest)
class DisposalRequestAdmin(admin.ModelAdmin):
    list_display = (
        "disposal_no", "asset", "status", "disposal_method",
        "salvage_value", "approving_manager", "is_locked",
    )
    list_filter = ("status", "disposal_method", "is_locked")
    search_fields = ("disposal_no", "asset__asset_id")
    readonly_fields = ("disposal_no",)
