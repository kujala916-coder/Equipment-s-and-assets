from django import forms

from .models import DisposalRequest


class BootstrapModelForm(forms.ModelForm):
    """Adds Bootstrap classes to every widget automatically (matches the
    styling convention used across vendors/procurement/contracts)."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            if isinstance(field.widget, forms.CheckboxInput):
                field.widget.attrs['class'] = 'form-check-input'
            else:
                field.widget.attrs['class'] = 'form-control'


class DisposalRequestForm(BootstrapModelForm):
    class Meta:
        model = DisposalRequest
        fields = ["asset", "reason"]
        widgets = {
            "reason": forms.Textarea(attrs={"rows": 3}),
        }


class DisposalApprovalForm(BootstrapModelForm):
    class Meta:
        model = DisposalRequest
        fields = ["disposal_method", "salvage_value", "approval_remarks"]
