"""
Module 12 -- Disposal Management

Workflow (per the refined requirements matrix):
  1. A Disposal request is created for an asset (12.40) -- the asset does NOT
     need to be UN-SERVICEABLE yet at this point, a request just starts the
     process.
  2. Technical inspection/certification (handled in it_assets.RepairRecord,
     certified_unserviceable=True) moves the asset into the controlled
     UN-SERVICEABLE inventory pool (12.60, Asset.status = UNSERVICEABLE).
  3. Disposal can only be *approved* once the linked asset is certified
     UN-SERVICEABLE (12.10, 12.50) -- enforced in DisposalRequest.can_approve()
     and re-checked in the view.
  4. Approval records the approving manager, disposal method and salvage
     value (12.20).
  5. Finalising disposal sets the asset's final status to DISPOSED and locks
     the record from further edits (12.30).
"""
from django.conf import settings
from django.core.exceptions import ValidationError
from django.db import models


class DisposalRequest(models.Model):
    class Status(models.TextChoices):
        REQUESTED = "REQUESTED", "Requested"
        APPROVED = "APPROVED", "Approved"
        REJECTED = "REJECTED", "Rejected"
        DISPOSED = "DISPOSED", "Disposed"

    class Method(models.TextChoices):
        SALE = "SALE", "Sale / Auction"
        SCRAP = "SCRAP", "Scrap"
        DONATION = "DONATION", "Donation"
        DESTRUCTION = "DESTRUCTION", "Destruction"
        RETURN_TO_VENDOR = "RETURN_TO_VENDOR", "Return to Vendor"
        OTHER = "OTHER", "Other"

    disposal_no = models.CharField(max_length=30, unique=True, editable=False)
    asset = models.ForeignKey(
        "it_assets.Asset", on_delete=models.PROTECT, related_name="disposal_requests"
    )
    requested_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.PROTECT, related_name="+"
    )
    request_date = models.DateField(auto_now_add=True)
    reason = models.TextField(help_text="Why this asset is being proposed for disposal.")
    status = models.CharField(max_length=15, choices=Status.choices, default=Status.REQUESTED)

    # 12.20 -- approval fields
    approving_manager = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, blank=True,
        on_delete=models.SET_NULL, related_name="+",
    )
    disposal_method = models.CharField(max_length=20, choices=Method.choices, blank=True)
    salvage_value = models.DecimalField(
        max_digits=12, decimal_places=2, null=True, blank=True,
        help_text="Financial recovery / salvage value, if any.",
    )
    approval_remarks = models.TextField(blank=True)
    approved_at = models.DateTimeField(null=True, blank=True)

    # 12.30 -- final state lock
    disposed_at = models.DateTimeField(null=True, blank=True)
    is_locked = models.BooleanField(
        default=False, help_text="Locked once disposal is finalised -- no further edits allowed."
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]
        verbose_name = "Disposal Request"

    def __str__(self):
        return f"{self.disposal_no} -- {self.asset.asset_id} ({self.get_status_display()})"

    def save(self, *args, **kwargs):
        if not self.disposal_no:
            last = DisposalRequest.objects.order_by("-id").first()
            next_seq = (last.id + 1) if last else 1
            self.disposal_no = f"DISP-{next_seq:06d}"
        super().save(*args, **kwargs)

    def clean(self):
        if self.is_locked:
            raise ValidationError("This disposal record is finalised and locked -- it can no longer be edited.")

    # 12.10 / 12.50 -- disposal is blocked unless the asset has been
    # certified UN-SERVICEABLE by the technical inspection/repair workflow.
    def can_approve(self):
        from it_assets.models import Asset
        return self.asset.status == Asset.Status.UNSERVICEABLE
