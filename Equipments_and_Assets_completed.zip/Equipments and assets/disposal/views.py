from django.contrib import messages
from django.contrib.auth.decorators import login_required, permission_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone

from it_assets.models import Asset

from .forms import DisposalApprovalForm, DisposalRequestForm
from .models import DisposalRequest


def _block_post_without_add(request, codename):
    """View-only roles can GET these pages but must never be able to submit
    the form, even though they have view_* permission (same pattern used by
    vendors/procurement/contracts)."""
    if request.method == 'POST' and not request.user.has_perm(codename):
        raise PermissionDenied("You have view-only access and cannot add records.")


@login_required
@permission_required("disposal.view_disposalrequest", raise_exception=True)
def disposal_list(request):
    """12.40 -- create a retirement/disposal request. Lists every request
    with its current workflow status."""
    _block_post_without_add(request, "disposal.add_disposalrequest")
    if request.method == 'POST':
        form = DisposalRequestForm(request.POST)
        if form.is_valid():
            disposal = form.save(commit=False)
            disposal.requested_by = request.user
            disposal.save()
            messages.success(request, f"Disposal request {disposal.disposal_no} created.")
            return redirect('disposal:disposal_list')
    else:
        form = DisposalRequestForm()

    return render(request, 'disposal/disposal_list.html', {
        'form': form,
        'disposals': DisposalRequest.objects.select_related('asset', 'requested_by').all(),
        'can_add': request.user.has_perm('disposal.add_disposalrequest'),
    })


@login_required
@permission_required("disposal.view_disposalrequest", raise_exception=True)
def disposal_detail(request, pk):
    disposal = get_object_or_404(DisposalRequest, pk=pk)
    approval_form = DisposalApprovalForm(instance=disposal)
    return render(request, 'disposal/disposal_detail.html', {
        'disposal': disposal,
        'approval_form': approval_form,
        'can_approve': request.user.has_perm('disposal.change_disposalrequest'),
    })


@login_required
@permission_required("disposal.change_disposalrequest", raise_exception=True)
def disposal_approve(request, pk):
    """12.10 / 12.50 -- blocked unless the asset has been certified
    UN-SERVICEABLE by the technical inspection/repair workflow.
    12.20 -- records approving manager, disposal method and salvage value."""
    disposal = get_object_or_404(DisposalRequest, pk=pk)
    if disposal.is_locked:
        raise PermissionDenied("This disposal record is finalised and locked.")
    if disposal.status != DisposalRequest.Status.REQUESTED:
        messages.error(request, "This request has already been actioned.")
        return redirect('disposal:disposal_detail', pk=disposal.pk)

    if not disposal.can_approve():
        messages.error(
            request,
            f"Cannot approve -- asset {disposal.asset.asset_id} has not been certified "
            "UN-SERVICEABLE by a technical inspection yet. Close the fault/repair record "
            "with 'Certified UN-Serviceable' ticked first."
        )
        return redirect('disposal:disposal_detail', pk=disposal.pk)

    if request.method == 'POST':
        form = DisposalApprovalForm(request.POST, instance=disposal)
        if form.is_valid():
            disposal = form.save(commit=False)
            disposal.status = DisposalRequest.Status.APPROVED
            disposal.approving_manager = request.user
            disposal.approved_at = timezone.now()
            disposal.save()
            messages.success(request, f"Disposal request {disposal.disposal_no} approved.")
            return redirect('disposal:disposal_detail', pk=disposal.pk)
    else:
        form = DisposalApprovalForm(instance=disposal)

    return render(request, 'disposal/disposal_approve.html', {'disposal': disposal, 'form': form})


@login_required
@permission_required("disposal.change_disposalrequest", raise_exception=True)
def disposal_reject(request, pk):
    disposal = get_object_or_404(DisposalRequest, pk=pk)
    if disposal.is_locked:
        raise PermissionDenied("This disposal record is finalised and locked.")
    if request.method == 'POST':
        disposal.status = DisposalRequest.Status.REJECTED
        disposal.approval_remarks = request.POST.get('remarks', '').strip()
        disposal.save()
        messages.success(request, f"Disposal request {disposal.disposal_no} rejected.")
    return redirect('disposal:disposal_detail', pk=disposal.pk)


@login_required
@permission_required("disposal.change_disposalrequest", raise_exception=True)
def disposal_finalize(request, pk):
    """12.30 -- set the final asset status to DISPOSED after approved
    disposal and prevent normal operational edits to the finalised record."""
    disposal = get_object_or_404(DisposalRequest, pk=pk)
    if disposal.status != DisposalRequest.Status.APPROVED:
        messages.error(request, "Only an approved disposal request can be finalised.")
        return redirect('disposal:disposal_detail', pk=disposal.pk)

    if request.method == 'POST':
        disposal.status = DisposalRequest.Status.DISPOSED
        disposal.disposed_at = timezone.now()
        disposal.is_locked = True
        disposal.save()

        asset = disposal.asset
        asset.status = Asset.Status.DISPOSED
        asset.save(update_fields=['status'])

        messages.success(request, f"Disposal request {disposal.disposal_no} finalised -- asset marked DISPOSED.")
        return redirect('disposal:disposal_detail', pk=disposal.pk)

    return render(request, 'disposal/disposal_finalize.html', {'disposal': disposal})
