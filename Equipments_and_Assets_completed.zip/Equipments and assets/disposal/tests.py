from django.contrib.auth import get_user_model
from django.test import TestCase, override_settings

from it_assets.models import Asset, AssetCategory
from .models import DisposalRequest


@override_settings(ALLOWED_HOSTS=['testserver'])
class DisposalWorkflowTests(TestCase):
    def setUp(self):
        self.user = get_user_model().objects.create_superuser('admin', 'a@x.com', 'pw12345!')
        self.client.login(username='admin', password='pw12345!')
        cat = AssetCategory.objects.create(name='Laptop', code_prefix='LAP')
        self.asset = Asset.objects.create(category=cat, serial_number='SN1')
        self.req = DisposalRequest.objects.create(asset=self.asset, requested_by=self.user, reason='old')

    def test_approval_blocked_until_certified_unserviceable(self):
        self.client.post(f'/disposal/{self.req.pk}/approve/', {'disposal_method': 'SCRAP'})
        self.req.refresh_from_db()
        self.assertEqual(self.req.status, DisposalRequest.Status.REQUESTED)

    def test_full_workflow_locks_record_and_disposes_asset(self):
        self.asset.status = Asset.Status.UNSERVICEABLE
        self.asset.save()
        self.client.post(f'/disposal/{self.req.pk}/approve/', {'disposal_method': 'SCRAP', 'salvage_value': '50'})
        self.client.post(f'/disposal/{self.req.pk}/finalize/')
        self.req.refresh_from_db()
        self.asset.refresh_from_db()
        self.assertTrue(self.req.is_locked)
        self.assertEqual(self.asset.status, Asset.Status.DISPOSED)
